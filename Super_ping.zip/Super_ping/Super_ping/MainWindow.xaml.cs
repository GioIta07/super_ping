﻿using System.Net.NetworkInformation;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Windows.Threading;

namespace Super_ping
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        BitmapImage bi1 = new BitmapImage();
        BitmapImage bi2 = new BitmapImage();
        BitmapImage bi3 = new BitmapImage();

        private DispatcherTimer _timer;
        private Ping _ping;
        private string[] _ipAddresses = new string[10]; // Array di IP
        private string[] _hostNames = new string[10]; // Array di nomi host (opzionali)
        public MainWindow()
        {

            InitializeComponent();
            _ping = new Ping();
            _timer = new DispatcherTimer
            {
                Interval = TimeSpan.FromSeconds(60) // Intervallo di 60 secondi
            };
            _timer.Tick += Timer_Tick;

           
        }

        // Metodo chiamato ad ogni tick del timer (ogni 60 secondi)
        private async void Timer_Tick(object sender, EventArgs e)
        {
            for (int i = 0; i < 10; i++)
            {
                string ip = _ipAddresses[i];
                if (!string.IsNullOrWhiteSpace(ip))
                {
                    await PingHost(i, ip);
                }
                else
                {
                    UpdateStatus(i, "Indirizzo IP mancante", null, "red");
                }
            }
        }

        // Metodo per effettuare il ping a un host specifico
        private async Task PingHost(int index, string ipAddress)
        {
            try
            {
                var reply = await _ping.SendPingAsync(ipAddress, 1000); // Timeout 1000 ms
                if (reply.Status == IPStatus.Success)
                {
                    string time = $"{reply.RoundtripTime} ms";
                    Dispatcher.Invoke(() =>
                    {
                        UpdateStatus(index, "Online", time, "green");
                    });
                }
                else
                {
                    Dispatcher.Invoke(() =>
                    {
                        UpdateStatus(index, "Offline", null, "red");
                    });
                }
            }
            catch
            {
                Dispatcher.Invoke(() =>
                {
                    UpdateStatus(index, "Errore", null, "red");
                });
            }
        }

        // Aggiorna l'interfaccia in base allo stato del ping
        private void UpdateStatus(int index, string status, string time, string color)
        {
            Label statusLabel = (Label)FindName($"StatusLabel{index + 1}");
            Label pingResult = (Label)FindName($"PingResult{index + 1}");
            Image statusIcon = (Image)FindName($"StatusIcon{index + 1}");

            // Aggiorna lo stato
            if (statusLabel != null) statusLabel.Content = status;
            if (pingResult != null) pingResult.Content = time ?? "";

            // Imposta l'icona in base al colore
            if (statusIcon != null)
            {
                string iconPath = color == "green" ? "ok.png" :
                                  color == "red" ? "error.png" :
                                  "warning.png";
                statusIcon.Source = new BitmapImage(new Uri(iconPath, UriKind.Relative));
            }
        }

        // Avvia il monitoraggio dei ping
        private void StartButton_Click(object sender, RoutedEventArgs e)
        {
            // Carica gli indirizzi IP e nomi host dai TextBox
            for (int i = 0; i < 10; i++)
            {
                _hostNames[i] = ((TextBox)FindName($"HostName{i + 1}")).Text;
                _ipAddresses[i] = ((TextBox)FindName($"IPAddress{i + 1}")).Text;
            }

            _timer.Start(); // Avvia il timer
            StartButton.IsEnabled = false;
            
        }


        

        
    }
}